public class Students {
    private String id, name;
    static int students_count = 0;

    public Students(int id, String name) {
        this.id = "e" + id;
        this.name = name;
        students_count++;
    }

    public String getId() {
        return id;
    }

    public void setId(int id) {
        this.id = "e" + id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}