public class TestPoint {
    public static void main(String[] args) {
        PointThreeD p = PointThreeD.dataInput();
        System.out.println(p);
    }
}
