public class TestStudent {
    public static void main(String[] args) throws Exception {
        Student student = Student.dataInput();
        System.out.println(student);
    }
}
