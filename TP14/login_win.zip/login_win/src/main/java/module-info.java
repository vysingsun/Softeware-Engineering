module itc.i4.tp14 {
    requires javafx.controls;
    requires javafx.fxml;

    opens itc.i4.tp14 to javafx.fxml;
    exports itc.i4.tp14;
}
